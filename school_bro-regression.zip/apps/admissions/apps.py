from django.apps import AppConfig


class AdmissionsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.admissions'
    label = 'admissions'
    verbose_name = 'Admissions Management'

    def ready(self):
        import apps.admissions.signals.handlers  # noqa