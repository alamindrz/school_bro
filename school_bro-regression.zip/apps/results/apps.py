from django.apps import AppConfig


class ResultsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.results'
    label = 'results'
    verbose_name = 'Results Management'
    
    def ready(self):
        import apps.results.signals.handlers  # noqa